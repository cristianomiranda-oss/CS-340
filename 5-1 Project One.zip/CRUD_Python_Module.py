from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, userName, passWord, host, port, db, col): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 

        # Connection Variables 
        USER = userName 
        PASS = passWord 
        HOST = host 
        PORT = port 
        DB = db 
        COL = col
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient(f"mongodb://{USER}:{PASS}@{HOST}:{PORT}")
        self.database = self.client[DB] 
        self.collection = self.database[COL] 
        
        ## Debug command for validating that he database was properly constructed
        # print("DB Initialized")
    
    ## Tests the connection to the database 
    def con_test(self):
        try:
            # Runs a ping command on the database and returns successful in the command goes through
            self.client.admin.command('ping')
            return "Connection successful"
        except Exception as e:
            # Throws an error to indicate the connection failed
            raise Exception(str(e)) 

    # Create a method to return the next available record number for use in the create method
    def getNextRecNum(self):
        aggregateCommand = [
            {"$group": 
             {"_id": None, 
              "highestRecNum": {"$max": "$rec_num"}}},
            {"$project": {"_id": 0, "highestRecNum": 1}}
        ]
        # Runs the aggregate command and returns a list containing an entry with the highest current rec_num
            # Accesses the first record in the returned list
        recNum = list(self.database.animals.aggregate(aggregateCommand))[0]
        # Returns the value associated with the highestRecNum key
        return recNum['highestRecNum'] + 1

    # Create method to add data to the array
        # data is passed in through a list so multiple documents can be added at once
    def create(self, docData):
        if docData:
            # Queries the database for the next rec_num value  
            nextRecNum = self.getNextRecNum()
            # Iterates through the docData array
            for i in range(len(docData)):
                # Adds the "rec_num" key and assigns it with the next rec_num value in the collection
                docData[i]['rec_num'] = nextRecNum
                # Increments the nextRecNum var for the next document
                nextRecNum += 1
                
            # Uses the insert many command to insert the array of new documents into the database
            result = self.database.animals.insert_many(docData)
            # Returns the associated acknowledged value to indicated if update was successful
            return result.acknowledged
        else: 
            # Throws an exception if no values are within the docData list
            raise Exception("Nothing to save, because docData parameter is empty") 

    # Read method to view documents from the database
        # a query filter can be passed in to view only specific documents
    def read(self, filterQuery):
        if filterQuery is None:
            # Returns a list of all documents
            return list(self.collection.find({}))
        else:
            # Returns a list of all documents matching the passed in query filter
            return list(self.collection.find(filterQuery))
    
    # Update method to update the information for specific documents
        # a query filter can be passed in to update only specific documents
        # and the field to update and its new value are passed in as well
    def update(self, filterQuery, updateData):
        if filterQuery is None:
            # Throws an exception to indicate the query filter was invalid
            raise Exception("Nothing to remove, because filterQuery parameter is empty")            
        elif updateData is None:
            # Throws an exception to indicate the update filter was invalid
            raise Exception("Nothing to remove, because updateData parameter is empty")            
        else:
            # Creates the default set update operation to change the current field's value to the passed in value
            update_operation = { '$set' : 
                updateData
            }
            
            # Updates the filtered documents
            result = self.database.animals.update_many(filterQuery, update_operation)
            # Returns the associated acknowledged value to indicated if update was successful
            return result.modified_count
        
    # Delete method to delete documents from the database
        # a query filter MUST be passed in to remove only specific documents
    def delete(self, filterQuery):
        if filterQuery is not None:
            # Calls the delete command to remove all documents matching the query
            result = self.database.animals.delete_many(filterQuery)
            # Returns the associated acknowledged value to indicated if update was successful
            return result.deleted_count
        else:
            raise Exception("Nothing to remove, because filterQuery parameter is empty")